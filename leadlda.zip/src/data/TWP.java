package data;

public class TWP implements Comparable{
	
	public String term="";
	public double prob=0;
	
	public TWP(String key,double val){
		this.term=key;
		this.prob=val;
	}

	public int compareTo(Object o) {
		TWP sd=this;
		TWP osd=(TWP)o;
		if(sd.prob<osd.prob)
			return 1;
		else if(sd.prob>osd.prob)
			return -1;
		else
			return 0;
	}
	

}
