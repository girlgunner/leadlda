package data;

import java.util.ArrayList;
import java.util.List;

public class Message {
	
	public String id="";
	public Message parent=null;
	public List<Message>children=new ArrayList<>();
	public int tid=0;//ID of the conversation tree
	
	public int topic=-1;
	public double leaderProb=0;
	public int leader=-1;
	
	public List<Word>words=new ArrayList<>();
	
	public Message(String id,Message parent,int tid,double leaderProb,List<Word>words){
		this.id=id;
		this.tid=tid;
		this.parent=parent;
		this.leaderProb=leaderProb;
		this.words=words;
		if(parent!=null)
			parent.children.add(this);
	}

}
