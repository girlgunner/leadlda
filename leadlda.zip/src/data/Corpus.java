package data;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Corpus {

	public List<Message>weibos=new ArrayList<>();
	public List<String>vocab=new ArrayList<>();
	public int treeSize=0;

	public Corpus(String dataFile,String vocabFile){
		readData(dataFile);
		readVocab(vocabFile);
	}
	public void readVocab(String file){
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String line="";
			while((line=br.readLine())!=null){
				String[] word=line.split("\\s");
				String term=word[0];
				int wid=Integer.parseInt(word[1]);
				for(int v=vocab.size();v<=wid;v++)
					vocab.add("");
				vocab.set(wid, term);
			}
			br.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void readData(String file){
		//In datafile, messages in the same tree are grouped together in BFS order
		Map<String,Message>wmap=new HashMap<>();
		try {
			BufferedReader br=new BufferedReader(new FileReader(file));
			String line="";
			treeSize=0;
			while((line=br.readLine())!=null){
				String[] data=line.split("\t");
				if(data.length<4)
					continue;
				String id=data[0];
				String pid=data[1];
				double leaderProb=Double.parseDouble(data[2]);
				String[] wids=data[3].split("\\s");
				List<Word>words=new ArrayList<>();
				for(String wid:wids){
					int v=Integer.parseInt(wid);
					words.add(new Word(v));
				}
				Message parent=null;
				if(!pid.equals("null"))
					parent=wmap.get(pid);
				int treeID=treeSize;
				if(parent!=null)
					treeID=parent.tid;
				else
					treeSize++;
				Message weibo=new Message(id,parent,treeID,leaderProb,words);
				weibos.add(weibo);
				wmap.put(id, weibo);
			}
			br.close();
		} catch (IOException e) {	
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
