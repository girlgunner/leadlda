package data;

public class Word {
	
	public int wid=0;
	public int background=-1;
	public int topic=-1;
	
	public Word(int wid){
		this.wid=wid;
	}

}
