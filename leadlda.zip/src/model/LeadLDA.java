package model;

import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import data.Corpus;
import data.TWP;
import data.Message;
import data.Word;

public class LeadLDA {
	
	//counters for Gibbs Sampling
	public int[][] NTW=null;
	public int[] STW=null;
	public int[][] NTT=null;
	public int[] STT=null;
	public int[][] NTR=null;
	public int[] STR=null;
	public int[] NB=null;
	public int SB=0;
	public int[][] NLB=null;
	public int[] SLB=null;
	
	//# of topics
	public int K=50;
	//Size of vocabulary
	public int V=5000;
	//# of conversation trees
	public int T=500;

	//The prior variables
	public double alpha=0.5;
	public double beta=0.1;
	public double gamma=0.5;
	public double delta=0.5;
	public double lambda=0.5;
	public double sigma=0.5;
	
	//tree-topic distribution
	public double[][] theta=null;
	//topic transition distribution from parents to followers
	public double[][] pi=null;
	//topic-word distribution
	public double[][] phi=null;
	
	//# of iteration
	public int itts=1000;
	
	public List<Message>weibos=new ArrayList<>();
	public List<String>vocab=new ArrayList<>();
	
	//The path to output model
	public String outputDir="";

	public LeadLDA(int K,Corpus corpus,String outputDir){

		this.K=K;

		this.alpha=50.0/K;
		this.gamma=50.0/K;

		this.weibos=corpus.weibos;
		this.vocab=corpus.vocab;
		
		this.V=vocab.size();
		this.T=corpus.treeSize;
		

		this.outputDir=outputDir;

		NTW=new int[K][V];
		STW=new int[K];
		NTT=new int[T][K];
		STT=new int[T];
		NTR=new int[K][K];
		STR=new int[K];
		NB=new int[V];
		SB=0;
		NLB=new int[2][2];
		SLB=new int[2];
		theta=new double[T][K];
		pi=new double[K][K];
		phi=new double[K][V];
		init();
	}

	public void init(){
		double[] zp=new double[K];
		for(int i=0;i<K;i++)
			zp[i]=1.0/K;
		double[] bp=new double[]{0.5,0.5};
		for(Message weibo:weibos){
			int z=multiSample(zp, 0);
			weibo.topic=z;
			Message parent=weibo.parent;
			if(parent==null)
				weibo.leaderProb=1.0;
			double leaderProb=weibo.leaderProb;
			int l=multiSample(new double[]{1.0-leaderProb,leaderProb},1);
			weibo.leader=l;
			int t=weibo.tid;
			if(l==1){
				NTT[t][z]++;
				STT[t]++;
			}
			else{
				int pz=parent.topic;
				NTR[pz][z]++;
				STR[pz]++;
			}
			List<Word>words=weibo.words;
			for(Word word:words){
				int v=word.wid;
				int b=multiSample(bp,1);
				if(b==0){
					NTW[z][v]++;
					STW[z]++;
				}
				else{
					NB[v]++;
					SB++;
				}
				NLB[l][b]++;
				SLB[l]++;
				word.background=b;
			}
		}
	}

	public int multiSample(double[] distribution,int deft){
		double random=Math.random();
		double acc=0;
		int sample=0;
		int i=0;
		for(i=0;i<distribution.length;i++){
			double prob=distribution[i];
			if(prob<=0)
				continue;
			acc+=prob;
			if(acc>random)
				break;
		}
		sample=i;
		if(sample>=distribution.length)
			return deft;
		else
			return sample;
	}

	public void sampleWeibo(Message weibo){
		int cz=weibo.topic;
		int cl=weibo.leader;
		int t=weibo.tid;
		double leaderProb=weibo.leaderProb;
		Message parent=weibo.parent;
		List<Message>children=weibo.children;
		List<Word>words=weibo.words;
		Map<Integer,Integer>tfs=new HashMap<>();
		int[] bfs=new int[2];
		if(cl==1){
			NTT[t][cz]--;
			STT[t]--;
		}
		else{
			int pz=parent.topic;
			NTR[pz][cz]--;
			STR[pz]--;
		}
		for(Message child:children){
			int chz=child.topic;
			int chl=child.leader;
			if(chl==0){
				NTR[cz][chz]--;
				STR[cz]--;
			}
		}
		for(Word word:words){
			int cb=word.background;
			int v=word.wid;
			bfs[cb]++;
			NLB[cl][cb]--;
			SLB[cl]--;
			if(cb==0){
				NTW[cz][v]--;
				STW[cz]--;
				if(!tfs.containsKey(v))
					tfs.put(v, 0);
				int tf=tfs.get(v);
				tfs.put(v, tf+1);
			}
		}
		double[] dis=new double[K*2];
		for(int l=0;l<2;l++){
			for(int z=0;z<K;z++){
				int i=l*K+z;
				if(l==1)
					dis[i]+=Math.log(leaderProb);
				else
					dis[i]+=Math.log(1-leaderProb);
				if(l==0){
					if(leaderProb==1){
						dis[i]=Double.NEGATIVE_INFINITY;
						continue;
					}
					int[][] CTR=new int[K][K];
					int pz=parent.topic;
					CTR[pz][z]++;
					for(Message child:children){
						int chz=child.topic;
						int chl=child.leader;
						if(chl==0)
							CTR[z][chz]++;
					}
					for(int st=0;st<K;st++){
						int sn=0;
						for(int ed=0;ed<K;ed++){
							for(int n=0;n<CTR[st][ed];n++){
								dis[i]+=Math.log(NTR[st][ed]+n+gamma);
								dis[i]-=Math.log(STR[st]+sn+K*gamma);
								sn++;
							}
						}
					}
				}
				else{
					if(leaderProb==0){
						dis[i]=Double.NEGATIVE_INFINITY;
						continue;
					}
					dis[i]+=Math.log(NTT[t][z]+alpha);
					dis[i]-=Math.log(STT[t]+K*alpha);
				}
				int sn=0;
				for(int b=0;b<2;b++){
					for(int n=0;n<bfs[b];n++){
						dis[i]+=Math.log(NLB[l][b]+n+delta);
						dis[i]-=Math.log(SLB[l]+sn+2*delta);
						sn++;
					}
				}
				sn=0;
				for(int v:tfs.keySet()){
					for(int n=0;n<tfs.get(v);n++){
						dis[i]+=Math.log(NTW[z][v]+n+beta);
						dis[i]-=Math.log(STW[z]+sn+V*beta);
						sn++;
					}
				}
			}
		}
		dis=exp(dis);
		dis=normalize(dis);
		int sample=cl*K+cz;
		sample=multiSample(dis,sample);
		cz=sample%K;
		if(sample<K)
			cl=0;
		else
			cl=1;
		weibo.topic=cz;
		weibo.leader=cl;
		if(cl==1){
			NTT[t][cz]++;
			STT[t]++;
		}
		else{
			int pz=parent.topic;
			NTR[pz][cz]++;
			STR[pz]++;
		}
		for(Message child:children){
			int chz=child.topic;
			int chl=child.leader;
			if(chl==0){
				NTR[cz][chz]++;
				STR[cz]++;
			}
		}
		for(Word word:words){
			int cb=word.background;
			int v=word.wid;
			NLB[cl][cb]++;
			SLB[cl]++;
			if(cb==0){
				NTW[cz][v]++;
				STW[cz]++;
			}
		}
	}

	public void sampleWord(Word word,Message weibo){
		int cb=word.background;
		int v=word.wid;
		int cl=weibo.leader;
		int cz=weibo.topic;
		if(cb==1){
			NB[v]--;
			SB--;
		}
		else{
			NTW[cz][v]--;
			STW[cz]--;
		}
		NLB[cl][cb]--;
		SLB[cl]--;
		double[] dis=new double[2];
		for(int b=0;b<2;b++){
			if(b==1){
				dis[b]+=Math.log(NB[v]+beta);
				dis[b]-=Math.log(SB+V*beta);
			}
			else{
				dis[b]+=Math.log(NTW[cz][v]+beta);
				dis[b]-=Math.log(STW[cz]+V*beta);
			}
			dis[b]+=Math.log(NLB[cl][b]+delta);
			dis[b]-=Math.log(SLB[cl]+2*delta);
		}
		dis=exp(dis);
		dis=normalize(dis);
		cb=multiSample(dis,cb);
		word.background=cb;
		if(cb==1){
			NB[v]++;
			SB++;
		}
		else{
			NTW[cz][v]++;
			STW[cz]++;
		}
		NLB[cl][cb]++;
		SLB[cl]++;
	}
	public double[] exp(double[] logdis){
		double max=Double.NEGATIVE_INFINITY;
		for(int i=0;i<logdis.length;i++){
			if(logdis[i]>max){
				max=logdis[i];
			}
		}
		double[] dis=new double[logdis.length];
		
		for(int i=0;i<dis.length;i++){
			if(max<-700){
				logdis[i]-=max;
			}
			dis[i]=Math.exp(logdis[i]);
		}
		return dis;
	}
	public double[] normalize(double[] dis){
		double sum=0;
		for(int i=0;i<dis.length;i++){
			sum+=dis[i];
		}
		if(sum>0){
			for(int i=0;i<dis.length;i++){
				dis[i]/=sum;
			}
		}
		return dis;
	}

	public void infer(){
		for(int i=1;i<=itts;i++){
			System.out.println("sampling #"+i);
			for(Message weibo:weibos){
				sampleWeibo(weibo);
				List<Word>words=weibo.words;
				for(Word word:words){
					sampleWord(word,weibo);
				}
			}
			if(i%50==0)
				conclude();
		}
	}
	public void conclude(){
		setPi();
		setPhi();
		setTheta();
		displayTopics();
		setTAs();
	}
	public void displayTopics(){
		try {
			PrintStream ps=new PrintStream(outputDir+"/topic.display");
			for(int z=0;z<K;z++){
				List<TWP>twps=new ArrayList<>();
				for(int v=0;v<V;v++){
					String term=vocab.get(v);
					double prob=phi[z][v];
					twps.add(new TWP(term,prob));
				}
				Collections.sort(twps);
				ps.println("Topic "+z+":");
				for(int v=0;v<20;v++){
					TWP twp=twps.get(v);
					ps.println(twp.term+" "+twp.prob);
				}
			}
			ps.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	public void setPi(){
		try {
			PrintStream ps=new PrintStream(outputDir+"/pi.model");
			for(int pz=0;pz<K;pz++){
				for(int z=0;z<K;z++){
					pi[pz][z]=(NTR[pz][z]+gamma)/(STR[pz]+K*gamma);
				}
				pi[pz]=normalize(pi[pz]);
				for(int z=0;z<K;z++){
					ps.print(pi[pz][z]+" ");
				}
				ps.println();
			}
			ps.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void setTheta(){
		try {
			PrintStream ps=new PrintStream(outputDir+"/theta.model");
			for(int t=0;t<T;t++){
				for(int z=0;z<K;z++){
					theta[t][z]=(NTT[t][z]+alpha)/(STT[t]+K*alpha);
				}
				theta[t]=normalize(theta[t]);
				for(int z=0;z<K;z++){
					ps.print(theta[t][z]+" ");
				}
				ps.println();
			}
			ps.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void setPhi(){
		try {
			PrintStream ps=new PrintStream(outputDir+"/phi.model");
			for(int z=0;z<K;z++){
				for(int v=0;v<V;v++){
					phi[z][v]=(NTW[z][v]+beta)/(STW[z]+V*beta);
				}
				phi[z]=normalize(phi[z]);
				for(int v=0;v<V;v++){
					ps.print(phi[z][v]+" ");
				}
				ps.println();
			}
			ps.close();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public void setTAs(){
		try {
			PrintStream ps=new PrintStream(outputDir+"/topics.assign");
			for(Message weibo:weibos){
				//				ps.println(weibo.id+" "+weibo.act+" "+weibo.leader+" "+weibo.topic);
				ps.println(weibo.id+" "+weibo.leader+" "+weibo.topic);
			}
			ps.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}
