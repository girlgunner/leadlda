package run;

import java.io.File;

import data.Corpus;
import model.LeadLDA;

public class Main {
	
	public static void main(String[] arg0){
		String dataFile=arg0[0];
		String vocabFile=arg0[1];
		int K=Integer.parseInt(arg0[2]);
		String outputDir=arg0[3];
		File outputFile=new File(outputDir);
		if(!outputFile.exists())
			outputFile.mkdirs();
		Corpus corpus=new Corpus(dataFile,vocabFile);
		LeadLDA lead=new LeadLDA(K,corpus,outputDir);
		lead.init();
		lead.infer();
	}

}
